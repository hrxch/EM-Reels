from flask import Flask, request, jsonify, send_file, render_template
from flask_cors import CORS
import os, subprocess, uuid, threading, random
from pathlib import Path
from datetime import datetime, timedelta

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
CORS(app)

UPLOAD_DIR = Path("uploads")
OUTPUT_DIR = Path("output")
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

jobs = {}

GPS_CITIES = [
    (40.7128, -74.0060), (34.0522, -118.2437), (41.8781, -87.6298),
    (29.7604, -95.3698), (33.4484, -112.0740), (39.9526, -75.1652),
    (29.4241, -98.4936), (32.7767, -96.7970), (30.2672, -97.7431),
    (30.3322, -81.6557), (37.3382, -121.8863), (32.7157, -117.1611),
    (37.7749, -122.4194), (47.6062, -122.3321), (39.7392, -104.9903),
    (36.1699, -115.1398), (35.2271, -80.8431), (25.7617, -80.1918),
    (36.1627, -86.7816), (33.7490, -84.3880), (42.3601, -71.0589),
    (45.5051, -122.6750), (44.9778, -93.2650), (38.2527, -85.7585),
    (39.1031, -84.5120), (41.4993, -81.6944), (35.4676, -97.5164),
    (32.2226, -110.9747), (35.1495, -90.0490), (38.9072, -77.0369),
]

IPHONE_PROFILES = [
    {"model": "iPhone 17 Pro",     "software": "iOS 26.2"},
    {"model": "iPhone 17 Pro Max", "software": "iOS 26.2"},
    {"model": "iPhone 16 Pro",     "software": "iOS 18.3.2"},
    {"model": "iPhone 16 Pro Max", "software": "iOS 18.3.2"},
]

STRENGTH_PARAMS = {
    1: {"crop_min": 0.02, "crop_max": 0.04, "bright": 0.02, "sat": 0.04, "con": 0.03},
    2: {"crop_min": 0.04, "crop_max": 0.08, "bright": 0.04, "sat": 0.08, "con": 0.05},
    3: {"crop_min": 0.07, "crop_max": 0.13, "bright": 0.06, "sat": 0.13, "con": 0.08},
}

ANCHORS_X = {"mc": 0.5, "tl": 0.0, "tr": 1.0, "bl": 0.0, "br": 1.0, "tc": 0.5, "bc": 0.5}
ANCHORS_Y = {"mc": 0.5, "tl": 0.0, "tr": 0.0, "bl": 1.0, "br": 1.0, "tc": 0.0, "bc": 1.0}
ANCHOR_ORDER = ["mc", "tl", "tr", "bl", "br"]


def get_random_metadata(profile=None):
    lat, lon = random.choice(GPS_CITIES)
    lat += random.uniform(-0.002, 0.002)
    lon += random.uniform(-0.002, 0.002)
    prof = profile or random.choice(IPHONE_PROFILES)
    ts = datetime.now() - timedelta(days=random.randint(0, 45))
    ts = ts.replace(hour=random.randint(8, 21), minute=random.randint(0, 59),
                    second=random.randint(0, 59))
    creation = ts.strftime("%Y-%m-%dT%H:%M:%S.") + f"{random.randint(0,999):03d}Z"
    lat_s = f"+{lat:.4f}" if lat >= 0 else f"{lat:.4f}"
    lon_s = f"+{lon:.4f}" if lon >= 0 else f"{lon:.4f}"
    location = f"{lat_s}{lon_s}/"
    return {
        "make": "Apple",
        "model": prof["model"],
        "software": prof["software"],
        "creation_time": creation,
        "location": location,
        "encoder": "com.apple.avfoundation.avcapturesession 800.17.2.0",
    }


def generate_spoof_configs(count, strength, custom_params=None):
    if custom_params:
        s = {
            "crop_min": float(custom_params.get("crop_min", 0.03)),
            "crop_max": float(custom_params.get("crop_max", 0.06)),
            "bright":   float(custom_params.get("bright",   0.04)),
            "sat":      float(custom_params.get("sat",      0.08)),
            "con":      float(custom_params.get("con",      0.05)),
        }
    else:
        s = STRENGTH_PARAMS.get(int(strength), STRENGTH_PARAMS[2])
    configs = []
    for i in range(int(count)):
        anchor = ANCHOR_ORDER[i % len(ANCHOR_ORDER)]
        crop = round(random.uniform(s["crop_min"], s["crop_max"]), 4)
        ax = ANCHORS_X[anchor]
        ay = ANCHORS_Y[anchor]
        scale_f = round(1.0 / (1.0 - crop), 6)
        configs.append({
            "type": "combo",
            "crop": crop, "ax": ax, "ay": ay, "scale": scale_f,
            "brightness": round(random.uniform(-s["bright"], s["bright"]), 4),
            "saturation": round(1.0 + random.uniform(-s["sat"], s["sat"]), 4),
            "contrast":   round(1.0 + random.uniform(-s["con"], s["con"]), 4),
            "label": f"Variation {i+1}",
        })
    return configs


def process_video(input_path, output_path, filters, audio_filters, meta):
    """Run FFmpeg with given filters + metadata. Returns True on success."""
    vf = ",".join(filters) if filters else "null"
    cmd = ["ffmpeg", "-y", "-i", input_path, "-vf", vf]

    if audio_filters:
        cmd += ["-af", ",".join(audio_filters), "-c:a", "aac", "-b:a", "192k"]
    else:
        cmd += ["-c:a", "copy"]

    cmd += ["-c:v", "libx264", "-crf", "18", "-preset", "ultrafast"]

    if meta:
        for k, v in meta.items():
            cmd += ["-metadata", f"{k}={v}"]
        cmd += ["-movflags", "use_metadata_tags+faststart"]

    cmd.append(output_path)
    r = subprocess.run(cmd, capture_output=True)
    return r.returncode == 0


def _ass_bg(hex_color, opacity):
    """Return ASS BackColour with alpha from opacity (0-1)."""
    h = hex_color.lstrip("#")
    alpha = int((1 - opacity) * 255)  # ASS alpha: 0=opaque, 255=transparent
    return f"&H{alpha:02X}{h[4:6]}{h[2:4]}{h[0:2]}&".upper()


def transcribe_to_ass(input_path, style, uid):
    """Transcribe audio from input_path and return path to .ass subtitle file, or None on failure."""
    font_name    = style.get("font", "Arial")
    font_size    = int(style.get("size", 60))
    color        = style.get("color", "#FFFFFF")
    outline_col  = style.get("outline_color", "#000000")
    outline      = int(style.get("outline", 3))
    bg_color     = style.get("bg_color", "#000000")
    bg_opacity   = float(style.get("bg_opacity", 0))
    position     = style.get("position", "bottom")
    wpl          = int(style.get("words_per_line", 4))
    karaoke      = style.get("karaoke", False)
    hl_color     = style.get("karaoke_color", "#FFE600")

    audio_path = str(OUTPUT_DIR / f"{uid}_audio.wav")
    subprocess.run(["ffmpeg", "-y", "-i", input_path, "-ar", "16000", "-ac", "1", audio_path],
                   capture_output=True)

    words = []
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel("tiny", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(audio_path, word_timestamps=True)
        for seg in segments:
            if hasattr(seg, "words") and seg.words:
                for w in seg.words:
                    words.append((w.start, w.end, w.word.strip()))
    except Exception:
        pass

    try:
        os.remove(audio_path)
    except Exception:
        pass

    if not words:
        return None

    def to_ass_color(h):
        h = h.lstrip("#")
        return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}&".upper()

    custom_y  = style.get("custom_y", None)
    align = 2; mv = 60
    if   position == "top":          align = 8; mv = 30
    elif position == "middle":       align = 5; mv = 0
    elif position == "lower_middle": align = 2; mv = 650   # ~64% from top (between middle & bottom)

    if karaoke:
        primary = to_ass_color(hl_color)
        secondary = to_ass_color(color)
    else:
        primary = to_ass_color(color)
        secondary = to_ass_color(color)

    header = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, "
        "Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Default,{font_name},{font_size},{primary},{secondary},"
        f"{to_ass_color(outline_col)},{_ass_bg(bg_color, bg_opacity)},"
        f"1,0,0,0,100,100,0,0,{'3' if bg_opacity > 0 else '1'},{0 if bg_opacity > 0 else outline},0,{align},20,20,{mv},1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )

    def ft(t):
        return f"{int(t//3600)}:{int((t%3600)//60):02d}:{t%60:05.2f}"

    pos_tag = f"{{\\an5\\pos(540,{int(float(custom_y)*1920/100)})}}" if custom_y is not None else ""
    dialogues = []
    for i in range(0, len(words), wpl):
        chunk = words[i:i+wpl]
        if karaoke:
            text = "".join(f"{{\\kf{max(1,int((we-ws)*100))}}}{w} " for ws,we,w in chunk).strip()
        else:
            text = " ".join(w[2] for w in chunk)
        dialogues.append(
            f"Dialogue: 0,{ft(chunk[0][0])},{ft(chunk[-1][1])},Default,,0,0,0,,{pos_tag}{text}"
        )

    ass_path = str(OUTPUT_DIR / f"{uid}_subs.ass")
    with open(ass_path, "w", encoding="utf-8") as f:
        f.write(header + "\n".join(dialogues))
    return ass_path


def process_variation(input_path, output_path, config, inject_meta=True, subtitle_ass=None):
    var_type = config.get("type", "combo")
    filters = []
    audio_filters = []

    if var_type == "combo":
        crop = float(config["crop"])
        ax   = float(config["ax"])
        ay   = float(config["ay"])
        sf   = float(config["scale"])
        b    = float(config.get("brightness", 0))
        s    = float(config.get("saturation", 1.0))
        c    = float(config.get("contrast", 1.0))
        filters = [
            f"crop=iw*{1-crop:.4f}:ih*{1-crop:.4f}:iw*{crop*ax:.4f}:ih*{crop*ay:.4f}",
            f"scale=trunc(iw*{sf:.4f}/2)*2:trunc(ih*{sf:.4f}/2)*2",
            f"eq=brightness={b:.4f}:saturation={s:.4f}:contrast={c:.4f}",
        ]

    elif var_type == "crop":
        amount = float(config.get("amount", 0.05))
        anchor = config.get("anchor", "mc")
        ax = ANCHORS_X.get(anchor, 0.5)
        ay = ANCHORS_Y.get(anchor, 0.5)
        sf = 1.0 / (1.0 - amount)
        filters = [
            f"crop=iw*{1-amount:.4f}:ih*{1-amount:.4f}:iw*{amount*ax:.4f}:ih*{amount*ay:.4f}",
            f"scale=trunc(iw*{sf:.4f}/2)*2:trunc(ih*{sf:.4f}/2)*2",
        ]

    elif var_type == "color":
        b = float(config.get("brightness", 0))
        s = float(config.get("saturation", 1.0))
        c = float(config.get("contrast", 1.0))
        filters = [f"eq=brightness={b:.4f}:saturation={s:.4f}:contrast={c:.4f}"]

    elif var_type == "speed":
        spd = float(config.get("speed", 1.0))
        filters = [f"setpts={1/spd:.4f}*PTS"]
        audio_filters = [f"atempo={min(max(spd, 0.5), 2.0):.4f}"]

    elif var_type == "noise":
        strength = int(config.get("strength", 15))
        amount = round(strength / 40 * 1.5, 2)
        filters = [f"unsharp=luma_msize_x=5:luma_msize_y=5:luma_amount={amount}"]

    elif var_type == "pixel":
        r = float(config.get("r", 1.005))
        g = float(config.get("g", 0.998))
        b_ch = float(config.get("b", 1.003))
        filters = [f"curves=r='0/0 1/{r:.4f}':g='0/0 1/{g:.4f}':b='0/0 1/{b_ch:.4f}'"]

    # Add invisible brightness seed for pixel-level uniqueness
    if inject_meta and var_type not in ("pixel",):
        filters.append(f"eq=brightness={round(random.uniform(0.002, 0.008), 4)}")

    # Burn subtitles (must be last filter, uses forward slashes for FFmpeg on Windows)
    if subtitle_ass:
        safe = subtitle_ass.replace("\\", "/")
        filters.append(f"ass={safe}")

    if inject_meta:
        audio_filters.insert(0, f"volume={round(random.uniform(0.97, 1.03), 3)}")

    meta = get_random_metadata() if inject_meta else None

    # Try full encode
    if process_video(input_path, output_path, filters, audio_filters, meta):
        return

    # Fallback: encode without complex filters, keep metadata
    if process_video(input_path, output_path, [], [], meta):
        return

    # Last resort: straight copy
    subprocess.run(["ffmpeg", "-y", "-i", input_path, "-c", "copy", output_path],
                   capture_output=True)


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/fonts")
def get_fonts():
    fonts = [
        "Poppins Bold", "Poppins Regular", "Liberation Sans Bold",
        "DejaVu Sans", "Lora", "FreeSerif Bold",
    ]
    return jsonify(fonts)

@app.route("/api/upload", methods=["POST"])
def upload():
    files = request.files.getlist("videos")
    saved = []
    for f in files:
        if f.filename:
            fid = str(uuid.uuid4())
            ext = Path(f.filename).suffix or ".mp4"
            path = UPLOAD_DIR / f"{fid}{ext}"
            f.save(path)
            saved.append({"id": fid, "name": f.filename, "path": str(path)})
    return jsonify(saved)

@app.route("/api/process", methods=["POST"])
def process():
    data = request.json
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"status": "running", "progress": 0, "files": [],
                    "error": None, "current_file": "", "current_index": 0, "total": 0}
    t = threading.Thread(target=run_job, args=(job_id, data), daemon=True)
    t.start()
    return jsonify({"job_id": job_id})

def run_job(job_id, data):
    try:
        files  = data.get("files", [])
        mode   = data.get("mode", "spoof")

        # ── SPOOF MODE ──────────────────────────────────────────────────────
        if mode == "spoof":
            strength      = int(data.get("strength", 2))
            inject_meta   = data.get("inject_meta", True)
            custom_params = data.get("custom_params", None)

            # Support batches array OR legacy single-count format
            raw_batches = data.get("batches", None)
            if not raw_batches:
                raw_batches = [{
                    "count": int(data.get("count", 3)),
                    "with_subtitles": data.get("with_subtitles", False),
                    "subtitle_style": data.get("subtitle_style", {}),
                }]

            # Pre-generate variation configs per batch
            batch_specs = []
            for b in raw_batches:
                cfgs = generate_spoof_configs(int(b.get("count", 1)), strength, custom_params)
                batch_specs.append((cfgs, b.get("with_subtitles", False), b.get("subtitle_style", {})))

            total = len(files) * sum(len(bc) for bc, _, _ in batch_specs)
            jobs[job_id]["total"] = total
            op = 0

            for fi, finfo in enumerate(files):
                inp  = finfo["path"]
                stem = Path(inp).stem
                for bi, (var_configs, with_subtitles, subtitle_style) in enumerate(batch_specs):
                    ass_path = None
                    if with_subtitles:
                        jobs[job_id]["current_file"] = f"Transcribing {Path(inp).name}…"
                        ass_path = transcribe_to_ass(inp, subtitle_style, f"{job_id}_{fi}_{bi}")
                    for vi, vcfg in enumerate(var_configs):
                        jobs[job_id]["current_file"]  = Path(inp).name
                        jobs[job_id]["current_index"] = op + 1
                        out_name = f"{job_id}_b{bi}_v{vi}_{fi}_{stem}.mp4"
                        out_path = str(OUTPUT_DIR / out_name)
                        process_variation(inp, out_path, vcfg, inject_meta, subtitle_ass=ass_path)
                        label = f"B{bi+1}_{vcfg['label'].replace(' ','_')}"
                        jobs[job_id]["files"].append({
                            "name": f"{stem}_{label}.mp4",
                            "path": out_path, "id": out_name,
                            "var_label": label,
                            "batch_index": bi,
                        })
                        op += 1
                        jobs[job_id]["progress"] = int((op / total) * 100)
                    if ass_path:
                        try: os.remove(ass_path)
                        except: pass

            jobs[job_id]["status"] = "done"
            jobs[job_id]["current_file"] = ""
            return

        # ── VARIATIONS MODE (legacy) ─────────────────────────────────────
        if mode == "variations":
            var_configs = data.get("var_configs", [
                {"type": "crop", "amount": 0.05, "anchor": "mc", "label": "Variation 1"}
            ])
            inject_meta = data.get("inject_meta", True)
            total = len(files) * len(var_configs)
            jobs[job_id]["total"] = total
            op = 0
            for vi, vcfg in enumerate(var_configs):
                for fi, finfo in enumerate(files):
                    inp = finfo["path"]
                    jobs[job_id]["current_file"]  = Path(inp).name
                    jobs[job_id]["current_index"] = op + 1
                    stem = Path(inp).stem
                    label = vcfg.get("label", f"Variation {vi+1}")
                    out_name = f"{job_id}_v{vi}_{fi}_{stem}.mp4"
                    out_path = str(OUTPUT_DIR / out_name)
                    process_variation(inp, out_path, vcfg, inject_meta)
                    jobs[job_id]["files"].append({
                        "name": f"{stem}_{label.replace(' ','_')}.mp4",
                        "path": out_path, "id": out_name, "var_label": label,
                    })
                    op += 1
                    jobs[job_id]["progress"] = int((op / total) * 100)
            jobs[job_id]["status"] = "done"
            jobs[job_id]["current_file"] = ""
            return

        # ── TEXT / SUBTITLE MODE ─────────────────────────────────────────
        total = len(files)
        jobs[job_id]["total"] = total
        for i, finfo in enumerate(files):
            inp = finfo["path"]
            jobs[job_id]["current_file"]  = Path(inp).name
            jobs[job_id]["current_index"] = i + 1
            out_name = f"{job_id}_{i}_{Path(inp).stem}.mp4"
            out_path = str(OUTPUT_DIR / out_name)
            if mode == "subtitle":
                process_subtitle(inp, out_path, data, job_id)
            else:
                process_text_overlay(inp, out_path, data)
            jobs[job_id]["files"].append({
                "name": Path(inp).stem + "_edited.mp4",
                "path": out_path, "id": out_name,
            })
            jobs[job_id]["progress"] = int(((i + 1) / total) * 100)
        jobs[job_id]["status"] = "done"

    except Exception as e:
        jobs[job_id]["status"] = "error"
        jobs[job_id]["error"] = str(e)


# ─── Text overlay ─────────────────────────────────────────────────────────────

def hex_to_ffmpeg_color(hex_color, opacity=1.0):
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    a = int(opacity * 255)
    return f"0x{a:02X}{r:02X}{g:02X}{b:02X}"

FONTS = {
    "Poppins Bold":         "/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf",
    "Poppins Regular":      "/usr/share/fonts/truetype/google-fonts/Poppins-Regular.ttf",
    "Liberation Sans Bold": "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "DejaVu Sans":          "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "Lora":                 "/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf",
    "FreeSerif Bold":       "/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf",
}

def process_text_overlay(input_path, output_path, data):
    texts = data.get("texts", [])
    if not texts:
        subprocess.run(["ffmpeg", "-y", "-i", input_path, "-c", "copy", output_path],
                       capture_output=True)
        return
    filter_parts = []
    for txt in texts:
        font_path = FONTS.get(txt.get("font", "Poppins Bold"), list(FONTS.values())[0])
        text = txt.get("text", "").replace("'", "\\'").replace(":", "\\:")
        size = txt.get("size", 40)
        color = hex_to_ffmpeg_color(txt.get("color", "#FFFFFF"))
        outline_color = hex_to_ffmpeg_color(txt.get("outline_color", "#000000"))
        bg_color = hex_to_ffmpeg_color(txt.get("bg_color", "#000000"), float(txt.get("bg_opacity", 0.5)))
        x_pos = f"(w*{float(txt.get('x',50))/100}-text_w/2)"
        y_pos = f"(h*{float(txt.get('y',50))/100}-text_h/2)"
        start = float(txt.get("start", 0))
        end   = txt.get("end", "")
        enable = f"between(t,{start},{end})" if end else f"gte(t,{start})"
        filter_parts.append(
            f"drawtext=fontfile='{font_path}':text='{text}':fontsize={size}"
            f":fontcolor={color}:x={x_pos}:y={y_pos}"
            f":borderw={int(txt.get('outline',2))}:bordercolor={outline_color}"
            f":box=1:boxcolor={bg_color}:boxborderw=8:enable='{enable}'"
        )
    vf = ",".join(filter_parts)
    r = subprocess.run(["ffmpeg", "-y", "-i", input_path, "-vf", vf, "-c:a", "copy", output_path],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise Exception(f"FFmpeg error: {r.stderr[-400:]}")


# ─── Subtitles ────────────────────────────────────────────────────────────────

def process_subtitle(input_path, output_path, data, job_id):
    style = data.get("subtitle_style", {})
    karaoke = style.get("karaoke", False)
    font_name = style.get("font", "Poppins Bold")
    font_path = FONTS.get(font_name, list(FONTS.values())[0])
    font_size = style.get("size", 36)
    color = style.get("color", "#FFFFFF")
    outline_color = style.get("outline_color", "#000000")
    outline = style.get("outline", 3)
    position = style.get("position", "bottom")
    words_per_line = int(style.get("words_per_line", 4))

    audio_path = str(OUTPUT_DIR / f"{job_id}_audio.wav")
    subprocess.run(["ffmpeg", "-y", "-i", input_path, "-ar", "16000", "-ac", "1", audio_path],
                   capture_output=True)
    words = []
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel("tiny", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(audio_path, word_timestamps=True)
        for seg in segments:
            if hasattr(seg, "words") and seg.words:
                for w in seg.words:
                    words.append((w.start, w.end, w.word.strip()))
    except Exception:
        words = []

    if karaoke and words:
        ass_path = build_karaoke_ass(words, style, job_id)
        r = subprocess.run(["ffmpeg", "-y", "-i", input_path, "-vf", f"ass={ass_path}",
                             "-c:a", "copy", output_path], capture_output=True)
    else:
        srt_path = str(OUTPUT_DIR / f"{job_id}_subs.srt")
        if words:
            lines = []
            for idx in range(0, len(words), words_per_line):
                chunk = words[idx:idx+words_per_line]
                def ft(t):
                    return f"{int(t//3600):02d}:{int((t%3600)//60):02d}:{int(t%60):02d},{int((t%1)*1000):03d}"
                lines.append(f"{idx//words_per_line+1}\n{ft(chunk[0][0])} --> {ft(chunk[-1][1])}\n{' '.join(w[2] for w in chunk)}\n")
            with open(srt_path, "w") as f:
                f.write("\n".join(lines))
        else:
            with open(srt_path, "w") as f:
                f.write("1\n00:00:00,000 --> 00:00:01,000\n[No speech]\n")

        ass_path = str(OUTPUT_DIR / f"{job_id}_subs.ass")
        subprocess.run(["ffmpeg", "-y", "-i", srt_path, ass_path], capture_output=True)
        ffcol = color.lstrip("#").upper()
        ffout = outline_color.lstrip("#").upper()
        force = (f"FontName={font_name},FontSize={font_size},"
                 f"PrimaryColour=&H00{ffcol},OutlineColour=&H00{ffout},"
                 f"Outline={outline},Shadow=0,Alignment=2,MarginV=50")
        r = subprocess.run(["ffmpeg", "-y", "-i", input_path,
                             "-vf", f"ass={ass_path}:force_style='{force}'",
                             "-c:a", "copy", output_path], capture_output=True)
        if r.returncode != 0:
            subprocess.run(["ffmpeg", "-y", "-i", input_path,
                             "-vf", f"subtitles={srt_path}",
                             "-c:a", "copy", output_path], capture_output=True)
    try:
        os.remove(audio_path)
    except Exception:
        pass


def build_karaoke_ass(words, style, job_id):
    font_name = style.get("font", "Arial")
    font_size = style.get("size", 36)
    base_color = style.get("color", "#FFFFFF")
    hl_color = style.get("karaoke_color", "#FFE600")
    outline_color = style.get("outline_color", "#000000")
    outline = style.get("outline", 3)
    position = style.get("position", "bottom")
    wpl = int(style.get("words_per_line", 4))

    def to_ass(h):
        h = h.lstrip("#")
        return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}&".upper()

    custom_y  = style.get("custom_y", None)
    align = 2; mv = 60
    if   position == "top":          align = 8; mv = 30
    elif position == "middle":       align = 5; mv = 0
    elif position == "lower_middle": align = 2; mv = 650   # ~64% from top (between middle & bottom)

    header = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
        "[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, "
        "OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, "
        "Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Default,{font_name},{font_size},{to_ass(hl_color)},{to_ass(base_color)},"
        f"{to_ass(outline_color)},&H00000000,1,0,0,0,100,100,0,0,1,{outline},0,{align},20,20,{mv},1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )
    def ft(t):
        return f"{int(t//3600)}:{int((t%3600)//60):02d}:{t%60:05.2f}"

    pos_tag = f"{{\\an5\\pos(540,{int(float(custom_y)*1920/100)})}}" if custom_y is not None else ""
    dialogues = []
    for i in range(0, len(words), wpl):
        chunk = words[i:i+wpl]
        kara = "".join(f"{{\\kf{max(1, int((we-ws)*100))}}}{w} " for ws, we, w in chunk)
        dialogues.append(f"Dialogue: 0,{ft(chunk[0][0])},{ft(chunk[-1][1])},Default,,0,0,0,,{pos_tag}{kara.strip()}")

    ass_path = str(OUTPUT_DIR / f"{job_id}_karaoke.ass")
    with open(ass_path, "w", encoding="utf-8") as f:
        f.write(header + "\n".join(dialogues))
    return ass_path


# ─── Job / Download routes ────────────────────────────────────────────────────

@app.route("/api/job/<job_id>")
def job_status(job_id):
    return jsonify(jobs.get(job_id, {"status": "not_found"}))

@app.route("/api/download/<file_id>")
def download_file(file_id):
    path = OUTPUT_DIR / file_id
    if path.exists():
        return send_file(str(path), as_attachment=True)
    return "Not found", 404

@app.route("/api/download_all/<job_id>")
def download_all(job_id):
    import zipfile, io
    job = jobs.get(job_id)
    if not job or job["status"] != "done":
        return "Not ready", 400
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in job["files"]:
            if Path(f["path"]).exists():
                zf.write(f["path"], f["name"])
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"reels_{job_id[:8]}.zip",
                     mimetype="application/zip")

@app.route("/api/rename_job/<job_id>", methods=["POST"])
def rename_job(job_id):
    job = jobs.get(job_id)
    if not job:
        return "Not found", 404
    renames = request.json
    if not isinstance(renames, list):
        return "Bad request", 400
    rename_map = {r["id"]: r["new_name"] for r in renames if "id" in r and "new_name" in r}
    for f in job["files"]:
        if f["id"] in rename_map:
            f["name"] = rename_map[f["id"]]
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(port=7771, debug=False)
