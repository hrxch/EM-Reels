from flask import Flask, request, jsonify, send_file, render_template
from flask_cors import CORS
import os, re, subprocess, uuid, threading, random, math, shutil
from pathlib import Path
from datetime import datetime, timedelta

try:
    from PIL import Image, ImageEnhance
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    import piexif
    PIEXIF_AVAILABLE = True
except ImportError:
    PIEXIF_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True
CORS(app)

UPLOAD_DIR = Path("uploads")
OUTPUT_DIR = Path("output")
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

jobs = {}

# (lat, lon, city, timezone_offset)
USA_LOCATIONS = [
    (34.0522, -118.2437, "Los Angeles, CA",     "Pacific"),
    (40.7128, -74.0060,  "New York, NY",         "Eastern"),
    (25.7617, -80.1918,  "Miami, FL",            "Eastern"),
    (41.8781, -87.6298,  "Chicago, IL",          "Central"),
    (29.7604, -95.3698,  "Houston, TX",          "Central"),
    (33.4484, -112.0740, "Phoenix, AZ",          "Mountain"),
    (32.7157, -117.1611, "San Diego, CA",        "Pacific"),
    (32.7767, -96.7970,  "Dallas, TX",           "Central"),
    (30.2672, -97.7431,  "Austin, TX",           "Central"),
    (47.6062, -122.3321, "Seattle, WA",          "Pacific"),
    (39.7392, -104.9903, "Denver, CO",           "Mountain"),
    (33.7490, -84.3880,  "Atlanta, GA",          "Eastern"),
    (36.1699, -115.1398, "Las Vegas, NV",        "Pacific"),
    (45.5152, -122.6784, "Portland, OR",         "Pacific"),
    (37.7749, -122.4194, "San Francisco, CA",    "Pacific"),
]

# DST-aware timezone offsets (standard time used; close enough for metadata)
_TZ_OFFSETS = {
    "Eastern":  "-05:00",
    "Central":  "-06:00",
    "Mountain": "-07:00",
    "Pacific":  "-08:00",
}

IPHONE_PROFILES = [
    {
        "model": "iPhone 15 Pro",
        "ios_versions": ["17.6.1", "17.7", "18.0", "18.0.1", "18.1"],
        "lens": "Apple iPhone 15 Pro back triple camera 6.86mm f/1.78",
    },
    {
        "model": "iPhone 15 Pro Max",
        "ios_versions": ["17.6.1", "17.7", "18.0", "18.0.1", "18.1"],
        "lens": "Apple iPhone 15 Pro Max back triple camera 6.86mm f/1.78",
    },
    {
        "model": "iPhone 16 Pro",
        "ios_versions": ["18.0", "18.0.1", "18.1"],
        "lens": "Apple iPhone 16 Pro back triple camera 6.86mm f/1.78",
    },
    {
        "model": "iPhone 16 Pro Max",
        "ios_versions": ["18.0", "18.0.1", "18.1"],
        "lens": "Apple iPhone 16 Pro Max back triple camera 6.86mm f/1.78",
    },
]

STRENGTH_PARAMS = {
    # sat/con kept very subtle — most detection is visual/audio fingerprint, not color
    1: {
        "crop_min": 0.015, "crop_max": 0.035,
        "bright": 0.01,  "sat": 0.015, "con": 0.010,
        "speed_range": 0.008,   # ±0.8%  speed shift
        "hue_range":   2.0,     # ±2°    hue rotation
        "grain":       5,       # noise strength (additive)
        "rotate_max":  0.25,    # ±0.25° slight tilt
        "pitch_range": 0.004,   # ±0.4%  audio pitch shift
    },
    2: {
        "crop_min": 0.030, "crop_max": 0.060,
        "bright": 0.015, "sat": 0.020, "con": 0.015,
        "speed_range": 0.015,
        "hue_range":   4.0,
        "grain":       10,
        "rotate_max":  0.45,
        "pitch_range": 0.007,
    },
    3: {
        "crop_min": 0.050, "crop_max": 0.090,
        "bright": 0.020, "sat": 0.030, "con": 0.020,
        "speed_range": 0.022,
        "hue_range":   6.0,
        "grain":       16,
        "rotate_max":  0.65,
        "pitch_range": 0.012,
    },
}

ANCHORS_X = {"mc": 0.5, "tl": 0.0, "tr": 1.0, "bl": 0.0, "br": 1.0, "tc": 0.5, "bc": 0.5}
ANCHORS_Y = {"mc": 0.5, "tl": 0.0, "tr": 0.0, "bl": 1.0, "br": 1.0, "tc": 0.0, "bc": 1.0}
ANCHOR_ORDER = ["mc", "tl", "tr", "bl", "br"]


def get_video_duration(path):
    r = subprocess.run(
        ["ffprobe", "-v", "quiet", "-show_entries", "format=duration",
         "-of", "csv=p=0", path],
        capture_output=True, text=True
    )
    try:
        return float(r.stdout.strip())
    except Exception:
        return None


def get_random_metadata(model_name=None):
    """Generate realistic iPhone video metadata."""
    # ── Device ──────────────────────────────────────────────────────────────
    if model_name and model_name != 'random':
        prof = next((p for p in IPHONE_PROFILES if p["model"] == model_name), None) \
               or random.choice(IPHONE_PROFILES)
    else:
        prof = random.choice(IPHONE_PROFILES)
    model   = prof["model"]
    ios_ver = random.choice(prof["ios_versions"])
    lens    = prof["lens"]

    # ── GPS (±0.05° ≈ ±5 km variation around city centre) ──────────────────
    lat0, lon0, city, tz_name = random.choice(USA_LOCATIONS)
    lat = round(lat0 + random.uniform(-0.05, 0.05), 6)
    lon = round(lon0 + random.uniform(-0.05, 0.05), 6)
    lat_s  = f"+{lat:.6f}" if lat >= 0 else f"{lat:.6f}"
    lon_s  = f"+{lon:.6f}" if lon >= 0 else f"{lon:.6f}"
    iso6709 = f"{lat_s}{lon_s}/"
    tz_off  = _TZ_OFFSETS[tz_name]

    # ── Timestamp (random day within last 30 days, daylight hours) ──────────
    ts = datetime.now() - timedelta(
        days=random.randint(0, 30),
        hours=random.randint(0, 13),     # offset from 08:00 start
        minutes=random.randint(0, 59),
        seconds=random.randint(0, 59),
    )
    ts = ts.replace(hour=max(8, min(ts.hour + 8, 21)))
    creation = ts.strftime(f"%Y-%m-%dT%H:%M:%S{tz_off}")

    # ── Camera settings ─────────────────────────────────────────────────────
    iso     = random.choice([64, 80, 100, 125, 160, 200, 250, 320, 400])
    shutter = random.choice([30, 60, 125, 250])

    return {
        # Standard container tags
        "make":             "Apple",
        "model":            model,
        "software":         f"iOS {ios_ver}",
        "creation_time":    creation,
        "location":         iso6709,
        "location-eng":     city,
        # Apple QuickTime atoms (read by iOS, macOS, Instagram, etc.)
        "com.apple.quicktime.make":                 "Apple",
        "com.apple.quicktime.model":                model,
        "com.apple.quicktime.software":             ios_ver,
        "com.apple.quicktime.location.ISO6709":     iso6709,
        "com.apple.quicktime.creationdate":         creation,
        # EXIF-style camera info
        "ISO":              str(iso),
        "aperture":         "f/1.78",
        "focal_length":     "24mm",
        "shutter_speed":    f"1/{shutter}",
        "white_balance":    "Auto",
        "flash":            "Off",
        "lens_model":       lens,
    }


def generate_spoof_configs(count, strength, custom_params=None, flip_mode="alternate"):
    if custom_params:
        s = {
            "crop_min":    float(custom_params.get("crop_min",    0.030)),
            "crop_max":    float(custom_params.get("crop_max",    0.060)),
            "bright":      float(custom_params.get("bright",      0.015)),
            "sat":         float(custom_params.get("sat",         0.020)),
            "con":         float(custom_params.get("con",         0.015)),
            "speed_range": float(custom_params.get("speed_range", 0.015)),
            "hue_range":   float(custom_params.get("hue_range",   4.0)),
            "grain":       int(custom_params.get("grain",         10)),
            "rotate_max":  float(custom_params.get("rotate_max",  0.45)),
            "pitch_range": float(custom_params.get("pitch_range", 0.007)),
        }
    else:
        s = STRENGTH_PARAMS.get(int(strength), STRENGTH_PARAMS[2])

    configs = []
    for i in range(int(count)):
        anchor = ANCHOR_ORDER[i % len(ANCHOR_ORDER)]
        crop   = round(random.uniform(s["crop_min"], s["crop_max"]), 4)
        ax     = ANCHORS_X[anchor]
        ay     = ANCHORS_Y[anchor]
        sf     = round(1.0 / (1.0 - crop), 6)
        speed  = round(1.0 + random.uniform(-s["speed_range"], s["speed_range"]), 5)
        pitch  = round(1.0 + random.uniform(-s["pitch_range"], s["pitch_range"]), 5)

        # flip_mode: "alternate" = odd variations get flipped, "all" = every one, "off" = none
        if   flip_mode == "all":       flip = True
        elif flip_mode == "off":       flip = False
        else:                          flip = (i % 2 == 1)   # alternate

        configs.append({
            "type":       "combo",
            "crop": crop, "ax": ax, "ay": ay, "scale": sf,
            "brightness": round(random.uniform(-s["bright"], s["bright"]), 4),
            "saturation": round(1.0 + random.uniform(-s["sat"], s["sat"]), 4),
            "contrast":   round(1.0 + random.uniform(-s["con"], s["con"]), 4),
            "speed":      speed,
            "hue":        round(random.uniform(-s["hue_range"], s["hue_range"]), 2),
            "grain":      random.randint(max(1, s["grain"] - 3), s["grain"] + 3),
            "rotate":     round(random.uniform(-s["rotate_max"], s["rotate_max"]), 3),
            "pitch":      pitch,
            "flip":       flip,
            "label":      f"Variation {i+1}",
        })
    return configs


def generate_spoof_configs_v2(count, techniques):
    """New API: generate per-variation configs from a techniques dict."""
    at = techniques.get("audio_timing",   {})
    vf = techniques.get("visual_filters", {})
    sc = techniques.get("size_crop",      {})
    tr = techniques.get("transform",      {})

    def rnd(t, lo, hi, digits=4):
        if not t.get("enabled"): return None
        return round(random.uniform(float(t.get("min", lo)), float(t.get("max", hi))), digits)

    configs = []
    for i in range(int(count)):
        anchor = ANCHOR_ORDER[i % len(ANCHOR_ORDER)]
        cfg = {"type": "combo_v2", "label": f"Variation {i+1}"}

        # ── Audio & Timing ────────────────────────────────────────────
        cfg["speed"]    = rnd(at.get("speed",    {}), 0.97, 1.02, 5) or 1.0
        cfg["volume"]   = rnd(at.get("volume",   {}), 0.93, 1.07, 3) or 1.0
        cfg["framerate"]= rnd(at.get("framerate",{}), 29.85, 30.15, 3)
        cfg["cut_start"]= rnd(at.get("cut_start",{}), 0.05, 0.20, 3) or 0.0
        cfg["cut_end"]  = rnd(at.get("cut_end",  {}), 0.05, 0.20, 3) or 0.0
        vb = at.get("video_bitrate", {}); cfg["video_bitrate"] = int(random.uniform(float(vb.get("min",4500)), float(vb.get("max",7500)))) if vb.get("enabled") else None
        ab = at.get("audio_bitrate", {}); cfg["audio_bitrate"] = int(random.uniform(float(ab.get("min",128)), float(ab.get("max",192)))) if ab.get("enabled") else None
        cfg["remove_audio"] = at.get("remove_audio", {}).get("enabled", False)
        ws_t = at.get("waveform_shift", {})
        cfg["waveform_shift"] = int(random.uniform(float(ws_t.get("min", 6)), float(ws_t.get("max", 15)))) if ws_t.get("enabled") else 0

        # ── Visual Filters ────────────────────────────────────────────
        cfg["saturation"]  = rnd(vf.get("saturation",  {}), 0.97, 1.03)
        cfg["contrast"]    = rnd(vf.get("contrast",    {}), 0.97, 1.03)
        cfg["brightness"]  = rnd(vf.get("brightness",  {}), -0.015, 0.01)
        cfg["gamma"]       = rnd(vf.get("gamma",       {}), 0.96, 1.04)
        cfg["vignette"]    = rnd(vf.get("vignette",    {}), 0.05, 0.15)
        cfg["noise"]       = rnd(vf.get("noise",       {}), 2, 5, 1)
        cfg["hue"]         = rnd(vf.get("hue_shift",   {}), 3, 6, 2)
        cfg["unsharp"]     = rnd(vf.get("unsharp",     {}), 0.5, 1.2, 3)
        cfg["color_mixer"] = rnd(vf.get("color_mixer", {}), 1.5, 3.5, 3)

        # ── Size & Crop ───────────────────────────────────────────────
        crop_t = sc.get("random_crop", {})
        crop_pct = (rnd(crop_t, 0.5, 2.5, 3) or 3.0) / 100.0
        cfg["crop"]  = crop_pct
        cfg["ax"]    = ANCHORS_X[anchor]
        cfg["ay"]    = ANCHORS_Y[anchor]
        cfg["scale"] = round(1.0 / (1.0 - crop_pct), 6)
        bb_t = sc.get("black_border", {})
        cfg["black_border"] = int(random.uniform(float(bb_t.get("min", 10)), float(bb_t.get("max", 30)))) if bb_t.get("enabled") else 0
        blr_t = sc.get("blur_border", {})
        cfg["blur_border"] = int(random.uniform(float(blr_t.get("min", 50)), float(blr_t.get("max", 100)))) if blr_t.get("enabled") else 0

        # ── Transform ─────────────────────────────────────────────────
        cfg["zoom"]   = rnd(tr.get("zoom",     {}), 1.01, 1.07, 4)
        cfg["rotate"] = rnd(tr.get("rotation", {}), -1.0, 1.0, 3) or 0.0
        cfg["lens"]   = rnd(tr.get("lens",     {}), 0.0003, 0.006, 4)

        px_t = tr.get("pixel_shift", {})
        if px_t.get("enabled"):
            cfg["pixel_x"] = max(1, round(random.uniform(float(px_t.get("min",1.5)), float(px_t.get("max",2.5)))))
            cfg["pixel_y"] = max(1, round(random.uniform(float(px_t.get("min",1.5)), float(px_t.get("max",2.5)))))
        else:
            cfg["pixel_x"] = cfg["pixel_y"] = 0

        flip_t = tr.get("flip", {})
        if flip_t.get("enabled"):
            mode = flip_t.get("mode", "alternate")
            cfg["flip"] = True if mode == "all" else (False if mode == "off" else i % 2 == 1)
        else:
            cfg["flip"] = False

        rs_t = tr.get("random_size", {})
        cfg["random_size"] = random.randint(1, 2) if rs_t.get("enabled") else 0

        configs.append(cfg)
    return configs


def process_video(input_path, output_path, filters, audio_filters, meta,
                  video_bitrate=None, audio_bitrate=None, remove_audio=False):
    """Run FFmpeg with given filters + metadata. Returns (success, stderr_snippet)."""
    vf = ",".join(filters) if filters else "null"
    cmd = ["ffmpeg", "-y", "-i", input_path, "-vf", vf]

    if remove_audio:
        cmd.append("-an")
    elif audio_filters:
        ab = f"{audio_bitrate}k" if audio_bitrate else "192k"
        cmd += ["-af", ",".join(audio_filters), "-c:a", "aac", "-b:a", ab]
    else:
        if audio_bitrate:
            cmd += ["-c:a", "aac", "-b:a", f"{audio_bitrate}k"]
        else:
            cmd += ["-c:a", "copy"]

    if video_bitrate:
        cmd += ["-c:v", "libx264", "-b:v", f"{video_bitrate}k", "-preset", "ultrafast"]
    else:
        cmd += ["-c:v", "libx264", "-crf", "18", "-preset", "ultrafast"]

    if meta:
        cmd += ["-map_metadata", "-1"]   # strip ALL source metadata first
        cmd += ["-fflags", "+bitexact"]  # remove FFmpeg encoder fingerprint
        for k, v in meta.items():
            cmd += ["-metadata", f"{k}={v}"]
        cmd += ["-movflags", "faststart"]

    cmd.append(output_path)
    r = subprocess.run(cmd, capture_output=True)
    err = r.stderr[-400:].decode(errors="ignore") if r.returncode != 0 else ""
    return r.returncode == 0, err


def _ass_bg(hex_color, opacity):
    """Return ASS BackColour with alpha from opacity (0-1)."""
    h = hex_color.lstrip("#")
    alpha = int((1 - opacity) * 255)  # ASS alpha: 0=opaque, 255=transparent
    return f"&H{alpha:02X}{h[4:6]}{h[2:4]}{h[0:2]}&".upper()


def transcribe_to_ass(input_path, style, uid):
    """Transcribe audio from input_path and return path to .ass subtitle file, or None on failure."""
    font_name    = style.get("font", "Arial")
    font_size    = int(style.get("size", 60))
    color        = style.get("color", "#FFFFFF")
    outline_col  = style.get("outline_color", "#000000")
    outline      = int(style.get("outline", 3))
    bg_color     = style.get("bg_color", "#000000")
    bg_opacity   = float(style.get("bg_opacity", 0))
    position     = style.get("position", "bottom")
    wpl          = int(style.get("words_per_line", 4))
    karaoke      = style.get("karaoke", False)
    hl_color     = style.get("karaoke_color", "#FFE600")

    audio_path = str(OUTPUT_DIR / f"{uid}_audio.wav")
    subprocess.run(["ffmpeg", "-y", "-i", input_path, "-ar", "16000", "-ac", "1", audio_path],
                   capture_output=True)

    words = []
    whisper_error = None
    try:
        from faster_whisper import WhisperModel
        model = WhisperModel("tiny", device="cpu", compute_type="int8")
        segments, _ = model.transcribe(audio_path, word_timestamps=True)
        for seg in segments:
            if hasattr(seg, "words") and seg.words:
                for w in seg.words:
                    words.append((w.start, w.end, w.word.strip()))
    except Exception as e:
        whisper_error = str(e)

    try:
        os.remove(audio_path)
    except Exception:
        pass

    if not words:
        if whisper_error:
            raise Exception(f"Whisper transcription failed: {whisper_error}")
        return None  # No speech detected

    def to_ass_color(h):
        h = h.lstrip("#")
        return f"&H00{h[4:6]}{h[2:4]}{h[0:2]}&".upper()

    custom_y  = style.get("custom_y", None)
    align = 2; mv = 60
    if   position == "top":          align = 8; mv = 30
    elif position == "middle":       align = 5; mv = 0
    elif position == "lower_middle": align = 2; mv = 650   # ~64% from top (between middle & bottom)

    if karaoke:
        primary = to_ass_color(hl_color)
        secondary = to_ass_color(color)
    else:
        primary = to_ass_color(color)
        secondary = to_ass_color(color)

    header = (
        "[Script Info]\nScriptType: v4.00+\nPlayResX: 1080\nPlayResY: 1920\n\n"
        "[V4+ Styles]\n"
        "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, "
        "Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, "
        "Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\n"
        f"Style: Default,{font_name},{font_size},{primary},{secondary},"
        f"{to_ass_color(outline_col)},{_ass_bg(bg_color, bg_opacity)},"
        f"1,0,0,0,100,100,0,0,{'3' if bg_opacity > 0 else '1'},{0 if bg_opacity > 0 else outline},0,{align},20,20,{mv},1\n\n"
        "[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\n"
    )

    def ft(t):
        return f"{int(t//3600)}:{int((t%3600)//60):02d}:{t%60:05.2f}"

    pos_tag = f"{{\\an5\\pos(540,{int(float(custom_y)*1920/100)})}}" if custom_y is not None else ""
    dialogues = []
    for i in range(0, len(words), wpl):
        chunk = words[i:i+wpl]
        if karaoke:
            text = "".join(f"{{\\kf{max(1,int((we-ws)*100))}}}{w} " for ws,we,w in chunk).strip()
        else:
            text = " ".join(w[2] for w in chunk)
        dialogues.append(
            f"Dialogue: 0,{ft(chunk[0][0])},{ft(chunk[-1][1])},Default,,0,0,0,,{pos_tag}{text}"
        )

    ass_path = str(OUTPUT_DIR / f"{uid}_subs.ass")
    with open(ass_path, "w", encoding="utf-8") as f:
        f.write(header + "\n".join(dialogues))
    return ass_path


def _apply_watermark(video_path, watermark):
    """Apply watermark overlay as a second FFmpeg pass (in-place replace)."""
    wm_path = watermark.get("path", "")
    if not wm_path or not os.path.exists(wm_path):
        return
    wm_size    = float(watermark.get("size",    100)) / 100.0
    wm_x       = float(watermark.get("x",        50))
    wm_y       = float(watermark.get("y",        50))
    wm_opacity = float(watermark.get("opacity",  0.5))
    x_expr = f"(W-w)*{wm_x/100:.4f}"
    y_expr = f"(H-h)*{wm_y/100:.4f}"
    temp_path = video_path + ".wm_tmp.mp4"
    cmd = [
        "ffmpeg", "-y", "-i", video_path, "-i", wm_path,
        "-filter_complex",
        f"[1:v]scale=iw*{wm_size:.4f}:-1,format=rgba,"
        f"colorchannelmixer=aa={wm_opacity:.4f}[wm];"
        f"[0:v][wm]overlay={x_expr}:{y_expr}:format=auto",
        "-c:v", "libx264", "-crf", "18", "-preset", "ultrafast",
        "-c:a", "copy", temp_path,
    ]
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode == 0:
        os.replace(temp_path, video_path)
    else:
        try: os.remove(temp_path)
        except Exception: pass


def process_variation(input_path, output_path, config, inject_meta=True, subtitle_ass=None, iphone_model='random', custom_dims=None, watermark=None):
    var_type = config.get("type", "combo")
    filters = []
    audio_filters = []

    if var_type == "combo":
        crop   = float(config["crop"])
        ax     = float(config["ax"])
        ay     = float(config["ay"])
        sf     = float(config["scale"])
        b      = float(config.get("brightness", 0))
        s      = float(config.get("saturation", 1.0))
        c      = float(config.get("contrast",   1.0))
        speed  = float(config.get("speed",      1.0))
        hue    = float(config.get("hue",        0.0))
        grain  = int(config.get("grain",        0))
        rotate = float(config.get("rotate",     0.0))
        pitch  = float(config.get("pitch",      1.0))
        flip   = bool(config.get("flip",        False))

        # 1. Crop from anchor corner (defeats spatial fingerprint)
        filters = [
            f"crop=iw*{1-crop:.4f}:ih*{1-crop:.4f}:iw*{crop*ax:.4f}:ih*{crop*ay:.4f}",
            f"scale=trunc(iw*{sf:.4f}/2)*2:trunc(ih*{sf:.4f}/2)*2",
        ]

        # 2. Speed shift — shifts every frame timestamp (very effective vs pHash)
        if abs(speed - 1.0) > 0.0001:
            filters.append(f"setpts={1.0/speed:.6f}*PTS")
            audio_filters.append(f"atempo={min(max(speed, 0.5), 2.0):.6f}")

        # 3. Slight rotation — breaks spatial hash completely
        if abs(rotate) > 0.05:
            rotate_rad = rotate * math.pi / 180.0
            # Rotate with transparent fill, then scale to fill frame (no black bars)
            cos_r = math.cos(abs(rotate_rad))
            sin_r = math.sin(abs(rotate_rad))
            # Scale needed so rotated content fills frame
            fill_scale = 1.0 / (cos_r - sin_r * (9.0 / 16.0))  # approx for 9:16
            fill_scale = min(fill_scale, 1.015)  # cap at 1.5% upscale
            filters.append(f"rotate={rotate_rad:.6f}:c=black@0:ow=iw:oh=ih")
            if fill_scale > 1.001:
                fs = round(fill_scale, 5)
                filters.append(f"scale=trunc(iw*{fs:.5f}/2)*2:trunc(ih*{fs:.5f}/2)*2")
                # Crop back to original frame size to remove any black edge
                inv = round(1.0 / fs, 5)
                filters.append(f"crop=trunc(iw*{inv:.5f}/2)*2:trunc(ih*{inv:.5f}/2)*2")

        disable_visual = config.get("disable_visual", False)

        # 4. Hue rotation — defeats color-based fingerprinting
        if not disable_visual and abs(hue) > 0.1:
            filters.append(f"hue=h={hue:.2f}")

        # 5. Brightness / saturation / contrast (very subtle — user request)
        if not disable_visual:
            filters.append(f"eq=brightness={b:.4f}:saturation={s:.4f}:contrast={c:.4f}")

        # 6. Film grain / noise — breaks pixel-level hash
        if not disable_visual and grain > 0:
            filters.append(f"noise=alls={grain}:allf=t+u")

        # 7. Unsharp pass — alters high-frequency pixel content (invisible, effective)
        if not disable_visual:
            filters.append("unsharp=luma_msize_x=3:luma_msize_y=3:luma_amount=0.4")

        # 8. Horizontal flip (alternating) — instant pHash mismatch
        if flip:
            filters.append("hflip")

        # 9. Audio pitch shift independent of speed (defeats audio fingerprinting)
        if abs(pitch - 1.0) > 0.0001:
            audio_filters.append(f"asetrate=44100*{pitch:.5f},aresample=44100")

        # 10. Blur border (complex filter graph using split+overlay)
        blur_b = int(config.get("blur_border", 0))
        if blur_b > 0:
            blur_r = max(5, blur_b // 2)
            filters.append(
                f"split[orig][bg];[bg]scale=iw*2:ih*2,"
                f"boxblur=luma_radius={blur_r}:luma_power=3,"
                f"scale=iw/2:ih/2[blurred];"
                f"[blurred][orig]overlay=(W-w)/2:(H-h)/2"
            )

    elif var_type == "combo_v2":
        pre_vf, pre_af, main_f = [], [], []

        # 0. Trim / Cut (MUST be first)
        cut_s = float(config.get("cut_start", 0.0))
        cut_e = float(config.get("cut_end",   0.0))
        if cut_s > 0 or cut_e > 0:
            if cut_e > 0:
                dur = get_video_duration(input_path)
                if dur and dur > cut_s + cut_e + 0.5:
                    end_t = round(dur - cut_e, 3)
                    pre_vf = [f"trim=start={cut_s:.3f}:end={end_t:.3f}", "setpts=PTS-STARTPTS"]
                    pre_af = [f"atrim=start={cut_s:.3f}:end={end_t:.3f}", "asetpts=PTS-STARTPTS"]
            else:
                pre_vf = [f"trim=start={cut_s:.3f}", "setpts=PTS-STARTPTS"]
                pre_af = [f"atrim=start={cut_s:.3f}", "asetpts=PTS-STARTPTS"]

        # 1. Crop + pixel shift (spatial fingerprint)
        crop  = float(config.get("crop",  0.03))
        ax    = float(config.get("ax",    0.5))
        ay    = float(config.get("ay",    0.5))
        sf    = float(config.get("scale", 1.0 / (1.0 - crop)))
        px_x  = int(config.get("pixel_x", 0))
        px_y  = int(config.get("pixel_y", 0))
        x_off = f"iw*{crop*ax:.4f}+{px_x}" if px_x else f"iw*{crop*ax:.4f}"
        y_off = f"ih*{crop*ay:.4f}+{px_y}" if px_y else f"ih*{crop*ay:.4f}"
        main_f += [
            f"crop=iw*{1-crop:.4f}:ih*{1-crop:.4f}:{x_off}:{y_off}",
            f"scale=trunc(iw*{sf:.4f}/2)*2:trunc(ih*{sf:.4f}/2)*2",
        ]

        # 2. Zoom (scale up then center-crop back)
        zoom = config.get("zoom")
        if zoom:
            z = float(zoom)
            inv_z = round(1.0 / z, 5)
            main_f.append(f"scale=trunc(iw*{z:.4f}/2)*2:trunc(ih*{z:.4f}/2)*2")
            main_f.append(f"crop=trunc(iw*{inv_z:.5f}/2)*2:trunc(ih*{inv_z:.5f}/2)*2")

        # 3. Speed + volume
        speed = float(config.get("speed", 1.0))
        if abs(speed - 1.0) > 0.0001:
            main_f.append(f"setpts={1.0/speed:.6f}*PTS")
            audio_filters.append(f"atempo={min(max(speed, 0.5), 2.0):.6f}")
        vol = config.get("volume")
        if vol is not None and abs(float(vol) - 1.0) > 0.001:
            audio_filters.append(f"volume={float(vol):.4f}")

        # 4. Framerate
        fps = config.get("framerate")
        if fps:
            main_f.append(f"fps={float(fps):.3f}")

        # 5. Rotation
        rotate = float(config.get("rotate", 0.0))
        if abs(rotate) > 0.05:
            rotate_rad = rotate * math.pi / 180.0
            main_f.append(f"rotate={rotate_rad:.6f}:c=black@0:ow=iw:oh=ih")

        # 6. Hue shift
        hue = config.get("hue")
        if hue is not None:
            main_f.append(f"hue=h={float(hue):.2f}")

        # 7. eq (saturation, contrast, brightness, gamma — all in one filter)
        sat = config.get("saturation"); con = config.get("contrast")
        bri = config.get("brightness"); gam = config.get("gamma")
        if any(x is not None for x in [sat, con, bri, gam]):
            eq_parts = []
            if sat is not None: eq_parts.append(f"saturation={float(sat):.4f}")
            if con is not None: eq_parts.append(f"contrast={float(con):.4f}")
            if bri is not None: eq_parts.append(f"brightness={float(bri):.4f}")
            if gam is not None: eq_parts.append(f"gamma={float(gam):.4f}")
            main_f.append(f"eq={':'.join(eq_parts)}")

        # 8. Vignette
        vig = config.get("vignette")
        if vig:
            vig_angle = round(float(vig) * math.pi, 4)
            main_f.append(f"vignette=angle={vig_angle:.4f}:mode=forward")

        # 9. Color channel mixer (very subtle — ±cmx% per channel)
        cmx = config.get("color_mixer")
        if cmx:
            dev = float(cmx) / 100.0
            rr = round(1.0 + random.uniform(-dev, dev), 5)
            gg = round(1.0 + random.uniform(-dev, dev), 5)
            bb = round(1.0 + random.uniform(-dev, dev), 5)
            main_f.append(f"colorchannelmixer={rr:.5f}:0:0:0:0:{gg:.5f}:0:0:0:0:{bb:.5f}:0:0:0:0:1")

        # 10. Noise
        noise = config.get("noise")
        if noise:
            main_f.append(f"noise=alls={max(1,int(float(noise)))}:allf=t+u")

        # 11. Unsharp mask
        unsharp = config.get("unsharp")
        if unsharp:
            main_f.append(f"unsharp=luma_msize_x=3:luma_msize_y=3:luma_amount={float(unsharp):.3f}")

        # 12. Flip (last visual filter, before subtitles)
        if config.get("flip"):
            main_f.append("hflip")

        # 13. Lens correction (barrel/pincushion distortion)
        lens = config.get("lens")
        if lens:
            lv = float(lens)
            main_f.append(f"lenscorrection=k1={lv:.5f}:k2={lv:.5f}")

        # 14. Random size (+1-2px to output dimensions)
        rs = int(config.get("random_size", 0))
        if rs > 0:
            main_f.append(f"scale=trunc((iw+{rs})/2)*2:trunc((ih+{rs})/2)*2")

        # 15. Black border (pad)
        bb = int(config.get("black_border", 0))
        if bb > 0:
            main_f.append(f"pad=iw+{2*bb}:ih+{2*bb}:{bb}:{bb}:black")

        # 16. Custom output dimensions
        if custom_dims:
            try:
                cw, ch = [int(x.strip()) for x in custom_dims.lower().split('x')]
                main_f.append(
                    f"scale={cw}:{ch}:force_original_aspect_ratio=decrease,"
                    f"pad={cw}:{ch}:(ow-iw)/2:(oh-ih)/2:black"
                )
            except Exception:
                pass

        # 17. Blur border (split+overlay filter graph — must be last before subtitle)
        blur_b = int(config.get("blur_border", 0))
        if blur_b > 0:
            blur_r = max(5, blur_b // 2)
            main_f.append(
                f"split[orig][bg];[bg]scale=iw*2:ih*2,"
                f"boxblur=luma_radius={blur_r}:luma_power=3,"
                f"scale=iw/2:ih/2[blurred];"
                f"[blurred][orig]overlay=(W-w)/2:(H-h)/2"
            )

        # 18. Waveform shift (insert silence at start of audio stream)
        ws = int(config.get("waveform_shift", 0))
        if ws > 0:
            audio_filters.append(f"adelay={ws}ms:all=1")

        filters = pre_vf + main_f
        audio_filters = pre_af + audio_filters

    elif var_type == "crop":
        amount = float(config.get("amount", 0.05))
        anchor = config.get("anchor", "mc")
        ax = ANCHORS_X.get(anchor, 0.5)
        ay = ANCHORS_Y.get(anchor, 0.5)
        sf = 1.0 / (1.0 - amount)
        filters = [
            f"crop=iw*{1-amount:.4f}:ih*{1-amount:.4f}:iw*{amount*ax:.4f}:ih*{amount*ay:.4f}",
            f"scale=trunc(iw*{sf:.4f}/2)*2:trunc(ih*{sf:.4f}/2)*2",
        ]

    elif var_type == "color":
        b = float(config.get("brightness", 0))
        s = float(config.get("saturation", 1.0))
        c = float(config.get("contrast", 1.0))
        filters = [f"eq=brightness={b:.4f}:saturation={s:.4f}:contrast={c:.4f}"]

    elif var_type == "speed":
        spd = float(config.get("speed", 1.0))
        filters = [f"setpts={1/spd:.4f}*PTS"]
        audio_filters = [f"atempo={min(max(spd, 0.5), 2.0):.4f}"]

    elif var_type == "noise":
        strength = int(config.get("strength", 15))
        amount = round(strength / 40 * 1.5, 2)
        filters = [f"unsharp=luma_msize_x=5:luma_msize_y=5:luma_amount={amount}"]

    elif var_type == "pixel":
        r = float(config.get("r", 1.005))
        g = float(config.get("g", 0.998))
        b_ch = float(config.get("b", 1.003))
        filters = [f"curves=r='0/0 1/{r:.4f}':g='0/0 1/{g:.4f}':b='0/0 1/{b_ch:.4f}'"]

    # Add invisible brightness seed for pixel-level uniqueness (only if no eq filter already applied)
    has_eq = any('eq=' in f for f in filters)
    if inject_meta and not has_eq:
        filters.append(f"eq=brightness={round(random.uniform(0.002, 0.008), 4)}")

    # Burn subtitles (must be last filter, uses forward slashes for FFmpeg on Windows)
    if subtitle_ass:
        safe = subtitle_ass.replace("\\", "/").replace("'", "\\'")
        filters.append(f"ass='{safe}'")

    if inject_meta and var_type != "combo_v2":
        audio_filters.insert(0, f"volume={round(random.uniform(0.97, 1.03), 3)}")

    meta = get_random_metadata(iphone_model) if inject_meta else None
    vb   = config.get("video_bitrate") if config.get("type") == "combo_v2" else None
    ab   = config.get("audio_bitrate") if config.get("type") == "combo_v2" else None
    ra   = config.get("remove_audio", False) if config.get("type") == "combo_v2" else False

    ok, err = process_video(input_path, output_path, filters, audio_filters, meta, vb, ab, ra)
    if ok:
        if watermark and watermark.get("path"):
            _apply_watermark(output_path, watermark)
        return
    # Retry without visual/audio filters (keeps metadata + subtitle burn)
    ok2, err2 = process_video(input_path, output_path, [], [], meta, vb, ab, ra)
    if ok2:
        if watermark and watermark.get("path"):
            _apply_watermark(output_path, watermark)
        return
    # Last-resort passthrough copy
    r = subprocess.run(["ffmpeg", "-y", "-i", input_path, "-c", "copy", output_path],
                       capture_output=True)
    if r.returncode != 0:
        ffmpeg_err = r.stderr[-400:].decode(errors="ignore")
        raise RuntimeError(f"FFmpeg failed for {Path(input_path).name}: {ffmpeg_err}")


# ─── Image Processing ────────────────────────────────────────────────────────

def build_image_exif(meta):
    """Build piexif EXIF bytes from a get_random_metadata() dict."""
    if not PIEXIF_AVAILABLE:
        return b""
    try:
        model   = meta.get("model", "iPhone 16 Pro")
        ios_ver = meta.get("software", "iOS 18.1").replace("iOS ", "")
        creation = meta.get("creation_time", "")
        try:
            dt = datetime.strptime(creation[:19], "%Y-%m-%dT%H:%M:%S")
            dt_str = dt.strftime("%Y:%m:%d %H:%M:%S").encode()
        except Exception:
            dt_str = datetime.now().strftime("%Y:%m:%d %H:%M:%S").encode()

        # Parse GPS from ISO6709 string e.g. "+34.052200-118.243700/"
        iso6709 = meta.get("location", "+34.052200-118.243700/")
        lat, lon = 34.0522, -118.2437
        try:
            m = re.match(r'([+-]?\d+\.\d+)([+-]\d+\.\d+)/', iso6709)
            if m:
                lat = float(m.group(1))
                lon = float(m.group(2))
        except Exception:
            pass

        def to_dms(deg):
            deg = abs(deg)
            d = int(deg)
            m = int((deg - d) * 60)
            s = round(((deg - d) * 60 - m) * 60 * 1000000)
            return [(d, 1), (m, 1), (s, 1000000)]

        iso_val     = int(meta.get("ISO", 100))
        shutter_str = meta.get("shutter_speed", "1/60")
        shutter_den = int(shutter_str.split("/")[1]) if "/" in shutter_str else 60
        lens        = meta.get("lens_model", "").encode()

        zeroth = {
            piexif.ImageIFD.Make:             b'Apple',
            piexif.ImageIFD.Model:            model.encode(),
            piexif.ImageIFD.Software:         f'iOS {ios_ver}'.encode(),
            piexif.ImageIFD.DateTime:         dt_str,
            piexif.ImageIFD.XResolution:      (72, 1),
            piexif.ImageIFD.YResolution:      (72, 1),
            piexif.ImageIFD.ResolutionUnit:   2,
        }
        exif = {
            piexif.ExifIFD.DateTimeOriginal:  dt_str,
            piexif.ExifIFD.DateTimeDigitized: dt_str,
            piexif.ExifIFD.ISOSpeedRatings:   iso_val,
            piexif.ExifIFD.ExposureTime:      (1, shutter_den),
            piexif.ExifIFD.FNumber:           (178, 100),
            piexif.ExifIFD.FocalLength:       (24, 1),
            piexif.ExifIFD.LensModel:         lens,
            piexif.ExifIFD.FlashPixVersion:   b'0100',
        }
        gps = {
            piexif.GPSIFD.GPSLatitudeRef:  b'N' if lat >= 0 else b'S',
            piexif.GPSIFD.GPSLatitude:     to_dms(lat),
            piexif.GPSIFD.GPSLongitudeRef: b'E' if lon >= 0 else b'W',
            piexif.GPSIFD.GPSLongitude:    to_dms(abs(lon)),
        }
        return piexif.dump({"0th": zeroth, "Exif": exif, "GPS": gps})
    except Exception:
        return b""


def generate_image_configs_simple(count):
    """Simple mode: subtle per-variation configs for image spoofing."""
    configs = []
    for i in range(count):
        anchor = ANCHOR_ORDER[i % len(ANCHOR_ORDER)]
        crop_pct = round(random.uniform(0.005, 0.015), 4)
        configs.append({
            "type":       "img_simple",
            "crop":       crop_pct,
            "ax":         ANCHORS_X[anchor],
            "ay":         ANCHORS_Y[anchor],
            "rotate":     round(random.uniform(-0.4, 0.4), 3),
            "saturation": round(random.uniform(0.97, 1.03), 4),
            "contrast":   round(random.uniform(0.97, 1.03), 4),
            "brightness": round(random.uniform(-0.01, 0.01), 4),
            "noise":      random.randint(1, 3),
            "flip":       (i % 2 == 1),
            "random_size": random.randint(0, 2),
        })
    return configs


def generate_image_configs(count, techniques):
    """Advanced mode: generate per-variation image configs from a techniques dict."""
    vf = techniques.get("visual_filters", {})
    tr = techniques.get("transform",      {})
    sc = techniques.get("size_crop",      {})

    def rnd(t, lo, hi, digits=4):
        if not t.get("enabled"): return None
        return round(random.uniform(float(t.get("min", lo)), float(t.get("max", hi))), digits)

    configs = []
    for i in range(count):
        anchor = ANCHOR_ORDER[i % len(ANCHOR_ORDER)]
        cfg = {"type": "img_advanced"}

        cfg["saturation"] = rnd(vf.get("saturation",  {}), 0.97, 1.03)
        cfg["contrast"]   = rnd(vf.get("contrast",    {}), 0.97, 1.03)
        cfg["brightness"] = rnd(vf.get("brightness",  {}), -0.015, 0.01)
        cfg["noise"]      = rnd(vf.get("noise",       {}), 1, 4, 1)
        cfg["hue"]        = rnd(vf.get("hue_shift",   {}), 2, 6, 2)

        cfg["zoom"]   = rnd(tr.get("zoom",     {}), 1.01, 1.05, 4)
        cfg["rotate"] = rnd(tr.get("rotation", {}), -0.5, 0.5, 3) or 0.0

        px_t = tr.get("pixel_shift", {})
        if px_t.get("enabled"):
            cfg["pixel_x"] = max(1, round(random.uniform(float(px_t.get("min", 1)), float(px_t.get("max", 2)))))
            cfg["pixel_y"] = max(1, round(random.uniform(float(px_t.get("min", 1)), float(px_t.get("max", 2)))))
        else:
            cfg["pixel_x"] = cfg["pixel_y"] = 0

        flip_t = tr.get("flip", {})
        if flip_t.get("enabled"):
            mode = flip_t.get("mode", "alternate")
            cfg["flip"] = True if mode == "all" else (False if mode == "off" else i % 2 == 1)
        else:
            cfg["flip"] = False

        rs_t = tr.get("random_size", {})
        cfg["random_size"] = random.randint(1, 2) if rs_t.get("enabled") else 0

        crop_t   = sc.get("random_crop", {})
        crop_pct = (rnd(crop_t, 0.3, 1.5, 3) or 1.0) / 100.0
        cfg["crop"] = crop_pct
        cfg["ax"]   = ANCHORS_X[anchor]
        cfg["ay"]   = ANCHORS_Y[anchor]

        configs.append(cfg)
    return configs


def process_image_variation(input_path, output_path, config, inject_meta=True, iphone_model='random'):
    """Process a single image with Pillow. Writes JPEG output."""
    if not PIL_AVAILABLE:
        raise RuntimeError("Pillow not installed. Run: pip install Pillow")

    img = Image.open(input_path).convert("RGB")
    orig_w, orig_h = img.size

    # 1. Rotation
    rotate = float(config.get("rotate", 0.0))
    if abs(rotate) > 0.05:
        img = img.rotate(-rotate, resample=Image.BICUBIC, expand=False)

    # 2. Random crop (anchor-based, scale back to original size)
    crop_pct = float(config.get("crop", 0.01))
    if crop_pct > 0:
        ax = float(config.get("ax", 0.5))
        ay = float(config.get("ay", 0.5))
        w, h = img.size
        cw = max(1, int(w * (1 - crop_pct)))
        ch = max(1, int(h * (1 - crop_pct)))
        x  = int(w * crop_pct * ax)
        y  = int(h * crop_pct * ay)
        img = img.crop((x, y, x + cw, y + ch))
        img = img.resize((w, h), Image.LANCZOS)

    # 3. Zoom (scale up then center-crop back)
    zoom = config.get("zoom")
    if zoom:
        z = float(zoom)
        w, h = img.size
        nw = max(1, int(w / z)); nh = max(1, int(h / z))
        left = (w - nw) // 2;   top  = (h - nh) // 2
        img = img.crop((left, top, left + nw, top + nh))
        img = img.resize((w, h), Image.LANCZOS)

    # 4. Saturation
    sat = config.get("saturation")
    if sat is not None:
        img = ImageEnhance.Color(img).enhance(float(sat))

    # 5. Contrast
    con = config.get("contrast")
    if con is not None:
        img = ImageEnhance.Contrast(img).enhance(float(con))

    # 6. Brightness (our bri is offset -0.02..+0.02; map to PIL multiplier)
    bri = config.get("brightness")
    if bri is not None:
        img = ImageEnhance.Brightness(img).enhance(max(0.1, 1.0 + float(bri) * 5))

    # 7. Noise (Gaussian)
    noise = config.get("noise")
    if noise and NUMPY_AVAILABLE:
        arr = np.array(img, dtype=np.float32)
        arr += np.random.normal(0, float(noise) * 3, arr.shape)
        img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))

    # 8. Pixel shift (roll)
    px_x = int(config.get("pixel_x", 0))
    px_y = int(config.get("pixel_y", 0))
    if (px_x or px_y) and NUMPY_AVAILABLE:
        arr = np.array(img)
        if px_x: arr = np.roll(arr, px_x, axis=1)
        if px_y: arr = np.roll(arr, px_y, axis=0)
        img = Image.fromarray(arr)

    # 9. Horizontal flip
    if config.get("flip"):
        img = img.transpose(Image.FLIP_LEFT_RIGHT)

    # 10. Random size (+1-2px)
    rs = int(config.get("random_size", 0))
    if rs > 0:
        w, h = img.size
        img = img.resize((w + rs, h + rs), Image.LANCZOS)

    # Build EXIF
    exif_bytes = b""
    if inject_meta:
        meta = get_random_metadata(iphone_model)
        exif_bytes = build_image_exif(meta)

    save_kwargs = {"quality": 92, "optimize": True}
    if exif_bytes:
        save_kwargs["exif"] = exif_bytes
    img.save(output_path, "JPEG", **save_kwargs)


def run_image_job(job_id, data):
    try:
        files        = data.get("files", [])
        count        = int(data.get("count", 3))
        inject_meta  = data.get("inject_meta", True)
        iphone_model = data.get("iphone_model", "random")
        techniques   = data.get("techniques", None)
        out_folder   = data.get("output_folder", None)

        cfgs = generate_image_configs(count, techniques) if techniques \
               else generate_image_configs_simple(count)

        total = len(files) * len(cfgs)
        jobs[job_id]["total"] = total
        op = 0

        for fi, finfo in enumerate(files):
            inp  = finfo["path"]
            stem = Path(inp).stem
            for vi, vcfg in enumerate(cfgs):
                jobs[job_id]["current_file"]  = Path(inp).name
                jobs[job_id]["current_index"] = op + 1
                out_name = f"{job_id}_img_{fi}_{vi}_{stem}.jpg"
                out_path = str(OUTPUT_DIR / out_name)
                process_image_variation(inp, out_path, vcfg, inject_meta, iphone_model)
                display_name = f"{stem}_v{vi+1}.jpg"
                if out_folder and os.path.exists(inp):
                    try:
                        os.makedirs(out_folder, exist_ok=True)
                        dest = os.path.join(out_folder, display_name)
                        if os.path.exists(dest):
                            base, ext2 = os.path.splitext(display_name)
                            dest = os.path.join(out_folder, f"{base}_{vi+1}{ext2}")
                        shutil.copy2(out_path, dest)
                    except Exception:
                        pass
                jobs[job_id]["files"].append({
                    "name": display_name, "path": out_path,
                    "id": out_name, "var_label": f"v{vi+1}",
                })
                op += 1
                jobs[job_id]["progress"] = int((op / total) * 100)

        jobs[job_id]["status"] = "done"
        jobs[job_id]["current_file"] = ""
    except Exception as e:
        jobs[job_id]["status"] = "error"
        jobs[job_id]["error"] = str(e)


# ─── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/browse_folder")
def browse_folder():
    """Open a native Windows folder picker and return the selected path."""
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.wm_attributes('-topmost', 1)
        folder = filedialog.askdirectory(title="Select Output Folder")
        root.destroy()
        return jsonify({"path": folder.replace("/", "\\") if folder else ""})
    except Exception as e:
        return jsonify({"path": "", "error": str(e)})


@app.route("/api/upload", methods=["POST"])
def upload():
    files = request.files.getlist("videos")
    saved = []
    for f in files:
        if f.filename:
            fid = str(uuid.uuid4())
            ext = Path(f.filename).suffix or ".mp4"
            path = UPLOAD_DIR / f"{fid}{ext}"
            f.save(path)
            saved.append({"id": fid, "name": f.filename, "path": str(path)})
    return jsonify(saved)

@app.route("/api/upload_images", methods=["POST"])
def upload_images():
    files = request.files.getlist("images")
    saved = []
    for f in files:
        if f.filename:
            fid = str(uuid.uuid4())
            ext = Path(f.filename).suffix or ".jpg"
            path = UPLOAD_DIR / f"{fid}{ext}"
            f.save(path)
            saved.append({"id": fid, "name": f.filename, "path": str(path)})
    return jsonify(saved)


@app.route("/api/process_images", methods=["POST"])
def process_images_route():
    data = request.json
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"status": "running", "progress": 0, "files": [],
                    "error": None, "current_file": "", "current_index": 0, "total": 0}
    t = threading.Thread(target=run_image_job, args=(job_id, data), daemon=True)
    t.start()
    return jsonify({"job_id": job_id})


@app.route("/api/process", methods=["POST"])
def process():
    data = request.json
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"status": "running", "progress": 0, "files": [],
                    "error": None, "current_file": "", "current_index": 0, "total": 0}
    t = threading.Thread(target=run_job, args=(job_id, data), daemon=True)
    t.start()
    return jsonify({"job_id": job_id})

def run_job(job_id, data):
    try:
        files  = data.get("files", [])
        mode   = data.get("mode", "spoof")

        # ── SPOOF MODE ──────────────────────────────────────────────────────
        if mode == "spoof":
            strength      = int(data.get("strength", 2))
            inject_meta   = data.get("inject_meta", True)
            iphone_model  = data.get("iphone_model", "random")
            custom_params = data.get("custom_params", None)
            flip_mode     = data.get("flip_mode", "alternate")  # "alternate"|"all"|"off"

            # Support batches array OR legacy single-count format
            raw_batches = data.get("batches", None)
            if not raw_batches:
                raw_batches = [{
                    "count": int(data.get("count", 3)),
                    "with_subtitles": data.get("with_subtitles", False),
                    "subtitle_style": data.get("subtitle_style", {}),
                }]

            # Pre-generate variation configs per batch
            techniques    = data.get("techniques",    None)
            custom_dims   = data.get("custom_dims",   None)
            watermark_data = data.get("watermark",    None)
            batch_specs = []
            for b in raw_batches:
                if techniques:
                    cfgs = generate_spoof_configs_v2(int(b.get("count", 1)), techniques)
                else:
                    cfgs = generate_spoof_configs(int(b.get("count", 1)), strength, custom_params, flip_mode)
                    # Apply simple-mode feature flags
                    simple_vis  = data.get("simple_visual_filters", True)
                    simple_blur = data.get("simple_blur_border", False)
                    for cfg in cfgs:
                        if not simple_vis:
                            cfg["disable_visual"] = True
                        if simple_blur:
                            cfg["blur_border"] = 100
                batch_specs.append((cfgs, b.get("with_subtitles", False), b.get("subtitle_style", {}), b.get("name", "")))

            total = len(files) * sum(len(bc) for bc, _, _, _ in batch_specs)
            jobs[job_id]["total"] = total
            op = 0

            for fi, finfo in enumerate(files):
                inp  = finfo["path"]
                stem = Path(inp).stem
                for bi, (var_configs, with_subtitles, subtitle_style, batch_name) in enumerate(batch_specs):
                    ass_path = None
                    if with_subtitles:
                        jobs[job_id]["current_file"] = f"Transcribing {Path(inp).name}…"
                        ass_path = transcribe_to_ass(inp, subtitle_style, f"{job_id}_{fi}_{bi}")
                    # Build a clean label from batch name or fallback
                    safe_name = re.sub(r'[^\w\-]', '_', batch_name).strip('_') if batch_name else f"V{bi+1}"
                    for vi, vcfg in enumerate(var_configs):
                        jobs[job_id]["current_file"]  = Path(inp).name
                        jobs[job_id]["current_index"] = op + 1
                        out_name = f"{job_id}_b{bi}_v{vi}_{fi}_{stem}.mp4"
                        out_path = str(OUTPUT_DIR / out_name)
                        process_variation(inp, out_path, vcfg, inject_meta, subtitle_ass=ass_path, iphone_model=iphone_model, custom_dims=custom_dims, watermark=watermark_data)
                        display_name = f"{stem}_{safe_name}.mp4"
                        pair_folder = finfo.get("output_folder") or None
                        if pair_folder and os.path.exists(out_path):
                            try:
                                os.makedirs(pair_folder, exist_ok=True)
                                dest = os.path.join(pair_folder, display_name)
                                if os.path.exists(dest):
                                    base, ext = os.path.splitext(display_name)
                                    dest = os.path.join(pair_folder, f"{base}_{vi+1}{ext}")
                                shutil.copy2(out_path, dest)
                            except Exception:
                                pass
                        jobs[job_id]["files"].append({
                            "name": display_name,
                            "path": out_path, "id": out_name,
                            "var_label": safe_name,
                            "batch_index": bi,
                        })
                        op += 1
                        jobs[job_id]["progress"] = int((op / total) * 100)
                    if ass_path:
                        try: os.remove(ass_path)
                        except: pass

            jobs[job_id]["status"] = "done"
            jobs[job_id]["current_file"] = ""
            return

        # ── VARIATIONS MODE (legacy) ─────────────────────────────────────
        if mode == "variations":
            var_configs = data.get("var_configs", [
                {"type": "crop", "amount": 0.05, "anchor": "mc", "label": "Variation 1"}
            ])
            inject_meta = data.get("inject_meta", True)
            total = len(files) * len(var_configs)
            jobs[job_id]["total"] = total
            op = 0
            for vi, vcfg in enumerate(var_configs):
                for fi, finfo in enumerate(files):
                    inp = finfo["path"]
                    jobs[job_id]["current_file"]  = Path(inp).name
                    jobs[job_id]["current_index"] = op + 1
                    stem = Path(inp).stem
                    label = vcfg.get("label", f"Variation {vi+1}")
                    out_name = f"{job_id}_v{vi}_{fi}_{stem}.mp4"
                    out_path = str(OUTPUT_DIR / out_name)
                    process_variation(inp, out_path, vcfg, inject_meta)
                    jobs[job_id]["files"].append({
                        "name": f"{stem}_{label.replace(' ','_')}.mp4",
                        "path": out_path, "id": out_name, "var_label": label,
                    })
                    op += 1
                    jobs[job_id]["progress"] = int((op / total) * 100)
            jobs[job_id]["status"] = "done"
            jobs[job_id]["current_file"] = ""
            return

        # ── TEXT / SUBTITLE MODE ─────────────────────────────────────────
        total = len(files)
        jobs[job_id]["total"] = total
        for i, finfo in enumerate(files):
            inp = finfo["path"]
            jobs[job_id]["current_file"]  = Path(inp).name
            jobs[job_id]["current_index"] = i + 1
            out_name = f"{job_id}_{i}_{Path(inp).stem}.mp4"
            out_path = str(OUTPUT_DIR / out_name)
            if mode == "subtitle":
                process_subtitle(inp, out_path, data, f"{job_id}_{i}")
            else:
                process_text_overlay(inp, out_path, data)
            jobs[job_id]["files"].append({
                "name": Path(inp).stem + "_edited.mp4",
                "path": out_path, "id": out_name,
            })
            jobs[job_id]["progress"] = int(((i + 1) / total) * 100)
        jobs[job_id]["status"] = "done"

    except Exception as e:
        jobs[job_id]["status"] = "error"
        jobs[job_id]["error"] = str(e)


# ─── Text overlay ─────────────────────────────────────────────────────────────

def hex_to_ffmpeg_color(hex_color, opacity=1.0):
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    a = int(opacity * 255)
    return f"0x{a:02X}{r:02X}{g:02X}{b:02X}"

# Windows system font paths for drawtext filter
FONTS = {
    "Impact":          "C:/Windows/Fonts/impact.ttf",
    "Arial":           "C:/Windows/Fonts/arial.ttf",
    "Arial Black":     "C:/Windows/Fonts/ariblk.ttf",
    "Georgia":         "C:/Windows/Fonts/georgia.ttf",
    "Verdana":         "C:/Windows/Fonts/verdana.ttf",
    "Tahoma":          "C:/Windows/Fonts/tahoma.ttf",
    "Times New Roman": "C:/Windows/Fonts/times.ttf",
    "Courier New":     "C:/Windows/Fonts/cour.ttf",
    "Trebuchet MS":    "C:/Windows/Fonts/trebuc.ttf",
}
FONT_FALLBACK = "C:/Windows/Fonts/arial.ttf"

def process_text_overlay(input_path, output_path, data):
    texts = data.get("texts", [])
    if not texts:
        subprocess.run(["ffmpeg", "-y", "-i", input_path, "-c", "copy", output_path],
                       capture_output=True)
        return
    filter_parts = []
    for txt in texts:
        font_path = FONTS.get(txt.get("font", "Arial"), FONT_FALLBACK)
        if not os.path.exists(font_path):
            font_path = FONT_FALLBACK
        text = txt.get("text", "").replace("'", "\\'").replace(":", "\\:")
        size = txt.get("size", 40)
        color = hex_to_ffmpeg_color(txt.get("color", "#FFFFFF"))
        outline_color = hex_to_ffmpeg_color(txt.get("outline_color", "#000000"))
        bg_color = hex_to_ffmpeg_color(txt.get("bg_color", "#000000"), float(txt.get("bg_opacity", 0.5)))
        x_pos = f"(w*{float(txt.get('x',50))/100}-text_w/2)"
        y_pos = f"(h*{float(txt.get('y',50))/100}-text_h/2)"
        start = float(txt.get("start", 0))
        end   = txt.get("end", "")
        enable = f"between(t,{start},{end})" if end else f"gte(t,{start})"
        filter_parts.append(
            f"drawtext=fontfile='{font_path}':text='{text}':fontsize={size}"
            f":fontcolor={color}:x={x_pos}:y={y_pos}"
            f":borderw={int(txt.get('outline',2))}:bordercolor={outline_color}"
            f":box=1:boxcolor={bg_color}:boxborderw=8:enable='{enable}'"
        )
    vf = ",".join(filter_parts)
    r = subprocess.run(["ffmpeg", "-y", "-i", input_path, "-vf", vf, "-c:a", "copy", output_path],
                       capture_output=True, text=True)
    if r.returncode != 0:
        raise Exception(f"FFmpeg error: {r.stderr[-400:]}")


# ─── Subtitles ────────────────────────────────────────────────────────────────

def process_subtitle(input_path, output_path, data, uid):
    style    = data.get("subtitle_style", {})
    ass_path = transcribe_to_ass(input_path, style, uid)
    if ass_path:
        safe = ass_path.replace("\\", "/").replace("'", "\\'")
        r = subprocess.run(
            ["ffmpeg", "-y", "-i", input_path,
             "-vf", f"ass='{safe}'",
             "-c:v", "libx264", "-crf", "18", "-preset", "ultrafast",
             "-c:a", "aac", "-b:a", "192k",
             output_path],
            capture_output=True
        )
        try: os.remove(ass_path)
        except: pass
        if r.returncode == 0:
            return
        # Surface the FFmpeg error so it shows in job status
        raise Exception(f"Subtitle burn failed: {r.stderr[-300:].decode(errors='ignore')}")
    # No speech detected — copy as-is
    subprocess.run(["ffmpeg", "-y", "-i", input_path, "-c", "copy", output_path], capture_output=True)



# ─── Job / Download routes ────────────────────────────────────────────────────

@app.route("/api/job/<job_id>")
def job_status(job_id):
    return jsonify(jobs.get(job_id, {"status": "not_found"}))

@app.route("/api/download/<file_id>")
def download_file(file_id):
    path = OUTPUT_DIR / file_id
    if path.exists():
        return send_file(str(path), as_attachment=True)
    return "Not found", 404

@app.route("/api/download_all/<job_id>")
def download_all(job_id):
    import zipfile, io
    job = jobs.get(job_id)
    if not job or job["status"] != "done":
        return "Not ready", 400
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in job["files"]:
            if Path(f["path"]).exists():
                zf.write(f["path"], f["name"])
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"reels_{job_id[:8]}.zip",
                     mimetype="application/zip")

@app.route("/api/thumb/<file_id>")
def get_thumb(file_id):
    """Extract first frame from uploaded video, return as JPEG."""
    import io, tempfile
    candidates = list(UPLOAD_DIR.glob(f"{file_id}.*"))
    if not candidates:
        return "Not found", 404
    src = str(candidates[0])
    with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as tmp:
        tmp_path = tmp.name
    r = subprocess.run(
        ["ffmpeg", "-y", "-i", src, "-vf", "scale=320:-1", "-frames:v", "1",
         "-f", "image2", tmp_path],
        capture_output=True
    )
    if r.returncode != 0 or not Path(tmp_path).exists():
        return "Failed", 500
    buf = io.BytesIO()
    with open(tmp_path, "rb") as f:
        buf.write(f.read())
    try: os.remove(tmp_path)
    except Exception: pass
    buf.seek(0)
    return send_file(buf, mimetype="image/jpeg")


@app.route("/api/rename_job/<job_id>", methods=["POST"])
def rename_job(job_id):
    job = jobs.get(job_id)
    if not job:
        return "Not found", 404
    renames = request.json
    if not isinstance(renames, list):
        return "Bad request", 400
    rename_map = {r["id"]: r["new_name"] for r in renames if "id" in r and "new_name" in r}
    for f in job["files"]:
        if f["id"] in rename_map:
            f["name"] = rename_map[f["id"]]
    return jsonify({"ok": True})


if __name__ == "__main__":
    app.run(port=7771, debug=False)
