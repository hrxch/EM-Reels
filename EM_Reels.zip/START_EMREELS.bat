@echo off
cd /d "%~dp0"
title EM Reels
color 0A

echo.
echo  ==========================================
echo    EM Reels - Video Spoofer
echo  ==========================================
echo.

:: ─── Step 1: Python ──────────────────────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [1/3] Python not found. Auto-installing...
    echo        This takes 1-2 minutes on first run.
    echo.
    winget install Python.Python.3.11 -e --silent --accept-package-agreements --accept-source-agreements
    :: Refresh user PATH from registry so python is found immediately
    for /f "usebackq tokens=2,*" %%A in (`reg query HKCU\Environment /v PATH 2^>nul`) do set "PATH=%%B;%PATH%"
    python --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo.
        echo  ERROR: Could not install Python automatically.
        echo  Please download from https://python.org
        echo  IMPORTANT: check "Add Python to PATH" during install.
        echo.
        pause
        exit /b 1
    )
    echo  [1/3] Python installed.
) else (
    for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo  [1/3] %%v found.
)

:: ─── Step 2: FFmpeg ──────────────────────────────────────────────────────────
ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [2/3] FFmpeg not found. Auto-installing...
    winget install Gyan.FFmpeg -e --silent --accept-package-agreements --accept-source-agreements
    :: Refresh system PATH
    for /f "usebackq tokens=2,*" %%A in (`reg query "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v PATH 2^>nul`) do set "PATH=%%B;%PATH%"
    ffmpeg -version >nul 2>&1
    if %errorlevel% neq 0 (
        echo  [2/3] FFmpeg installed. A restart may be needed if video processing fails.
    ) else (
        echo  [2/3] FFmpeg installed.
    )
) else (
    echo  [2/3] FFmpeg found.
)

:: ─── Step 3: Python packages ─────────────────────────────────────────────────
echo  [3/3] Checking packages...
python -m pip install -r requirements.txt -q --break-system-packages 2>nul
python -m pip install -r requirements.txt -q 2>nul
echo  [3/3] Packages OK.

:: ─── Create folders ──────────────────────────────────────────────────────────
if not exist uploads mkdir uploads
if not exist output  mkdir output

:: ─── Launch ──────────────────────────────────────────────────────────────────
echo.
echo  ==========================================
echo    Running at http://localhost:7771
echo    Close this window to stop.
echo  ==========================================
echo.

start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:7771"
python app.py

pause
