#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "  =========================================="
echo "    EM Reels - Starting up..."
echo "  =========================================="
echo ""

# ─── Step 1: Python ──────────────────────────────────────────────────────────
if command -v python3 &>/dev/null; then
    echo "  [1/3] $(python3 --version) found."
else
    echo "  [1/3] Python not found. Attempting install..."
    if command -v brew &>/dev/null; then
        brew install python
    else
        echo ""
        echo "  ERROR: Homebrew not found. Install it first:"
        echo "  /bin/bash -c \"\$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)\""
        echo ""
        echo "  Then re-run this script."
        read -p "  Press Enter to exit..."
        exit 1
    fi
    if ! command -v python3 &>/dev/null; then
        echo "  ERROR: Python install failed. Please install manually from https://python.org"
        read -p "  Press Enter to exit..."
        exit 1
    fi
    echo "  [1/3] Python installed."
fi

# ─── Step 2: FFmpeg ──────────────────────────────────────────────────────────
if command -v ffmpeg &>/dev/null; then
    echo "  [2/3] FFmpeg found."
else
    echo "  [2/3] FFmpeg not found. Attempting install..."
    if command -v brew &>/dev/null; then
        brew install ffmpeg
    else
        echo "  WARNING: Could not auto-install FFmpeg (Homebrew missing)."
        echo "  Install manually: https://ffmpeg.org/download.html"
    fi
    if command -v ffmpeg &>/dev/null; then
        echo "  [2/3] FFmpeg installed."
    else
        echo "  [2/3] FFmpeg still not found — video processing may fail."
    fi
fi

# ─── Step 3: Python packages ─────────────────────────────────────────────────
echo "  [3/3] Checking packages..."
python3 -m pip install -r requirements.txt -q 2>/dev/null || \
python3 -m pip install -r requirements.txt -q --break-system-packages 2>/dev/null
echo "  [3/3] Packages OK."

# ─── Create folders ──────────────────────────────────────────────────────────
mkdir -p uploads output

# ─── Launch ──────────────────────────────────────────────────────────────────
echo ""
echo "  =========================================="
echo "    Running at http://localhost:7771"
echo "    Close this window to stop."
echo "  =========================================="
echo ""

# Open browser after 2 seconds (works on macOS and Linux)
(sleep 2 && open "http://localhost:7771" 2>/dev/null || xdg-open "http://localhost:7771" 2>/dev/null) &

python3 app.py
